import { Component } from '@angular/core';
import { TopMenuComponent } from '../top-menu/top-menu.component';

@Component({
  selector: 'app-header',
  imports: [TopMenuComponent],
  templateUrl: './header.component.html',
  styleUrl: './header.component.scss'
})
export class HeaderComponent {

}
