import { Component } from '@angular/core';

@Component({
  selector: 'app-sorftware',
  imports: [],
  templateUrl: './sorftware.component.html',
  styleUrl: './sorftware.component.scss'
})
export class SorftwareComponent {

}
