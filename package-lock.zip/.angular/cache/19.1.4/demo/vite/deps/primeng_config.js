import {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
} from "./chunk-RJSZJYLR.js";
import "./chunk-LQRFDBJF.js";
import "./chunk-5SG6DHNN.js";
import "./chunk-DGS7NSVX.js";
import "./chunk-WDMUDEB6.js";
export {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
};
