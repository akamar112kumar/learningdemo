import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
} from "./chunk-FF47XQXI.js";
import "./chunk-TQZYBLYG.js";
import "./chunk-32WICQAY.js";
import "./chunk-FPO3XRGI.js";
import "./chunk-YHCV7DAQ.js";
export {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
};
